<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model{
    protected $guarded = [];

    public function services(){
        return $this->belongsToMany(ServiceCategory::class, 'appointment_services');
    }

    public function user(){
        return $this->belongsTo(User::class);
    }
}
