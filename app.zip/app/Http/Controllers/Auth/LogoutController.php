<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class LogoutController extends Controller{
    public function __invoke(){
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
        session()->flash('toast', ['type' => 'success', 'message' => 'خروج از حساب کاربری انجام شد']);
        return redirect()->route('home');
    }
}
